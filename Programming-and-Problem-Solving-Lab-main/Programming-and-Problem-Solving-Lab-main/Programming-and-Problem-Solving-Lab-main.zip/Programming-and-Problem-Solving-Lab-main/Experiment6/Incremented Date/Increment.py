'''Write a Python program to check if a given date is valid. If the date is valid, print the next day's date (incremented date). 
If the date is invalid, print "Invalid Date".'''

day = int(input())
month = int(input())
year = int(input())

flag = True

if year < 1 or month < 1 or month > 12:
    flag = False
else:
    if month in (1,3,5,7,8,10,12):
        maxdays = 31
    elif month in (4,6,9,11):
        maxdays = 30
    else:
        if (year % 400 == 0) or (year % 4 == 0 and year % 100 != 0):
            maxdays = 29
        else:
            maxdays = 28

    if day < 1 or day > maxdays:
        flag = False

if not flag:
    print("Invalid Date")
else:
    day += 1
    if day > maxdays:
        day = 1
        month += 1
    if month > 12:
        month = 1
        year += 1
    print(f"{day:02d}-{month:02d}-{year}")

